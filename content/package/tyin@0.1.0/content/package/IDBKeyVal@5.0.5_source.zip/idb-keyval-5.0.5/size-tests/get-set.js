import { get, set } from '../dist/esm/index.js';
a(get, set);
