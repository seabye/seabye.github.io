import {
  get,
  set,
  del,
  clear,
  keys,
  values,
  entries,
  setMany,
  update,
  getMany,
} from '../dist/esm/index.js';
a(get, set, del, clear, keys, values, entries, setMany, update, getMany);
