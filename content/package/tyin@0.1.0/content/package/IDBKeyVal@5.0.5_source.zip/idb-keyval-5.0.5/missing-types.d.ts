interface IDBObjectStore {
  openKeyCursor(
    range?: IDBKeyRange | IDBValidKey,
    direction?: IDBCursorDirection,
  ): IDBRequest;
}
