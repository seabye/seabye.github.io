declare module 'chai/chai' {
  var chai: typeof import('chai');
  export default chai;
}
