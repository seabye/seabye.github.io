---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

<!-- Bug reports without a minimal reproducible example will be closed (https://stackoverflow.com/help/minimal-reproducible-example). Ideally, the example should be accessible somewhere public, like jsbin, Glitch, jsfiddle, codepen etc etc -->
